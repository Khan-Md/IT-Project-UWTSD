<?php
		include 'core/init.php';
?>

<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Index</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />


</head>

<body>

<div id="outer">

<div id="wrapper">
	

<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

<div id="content">
<h1>Welcome To Nemesis Design Studio</h1>
<p>We are a complete Creative Design Studio based in London. We have an outstanding reputation for quality, bespoke Interior designs across all digital and printed media - including eCommerce Web design.</p>
          <img class="image-frame" src="images/small/small1.jpg" /> 
          <img class="image-frame" src="images/small/small2.jpg" />  
<h3>Our Story</h3>
          <p>Originally founded in 2010, for the past three years we have been delivering superior projects to our clients throughout London and across the country. Nemesis Design Studio has been ranked number 21 on the Interior Design Magazine’s 2012 List of the top 100 design firms in the world.<br> We have quickly grown from a London–based interior design & web designing firm to a large multi–disciplinary organisation consisting of 50 members in 3 offices across Central London. We have various Centres of Excellence across the firm, which are leveraged to create designs which exemplify excellence, innovation, responsibility, evoke emotion and add value. 
 </p>
          <h3>Our Design Philosophy</h3>
          <p>We design for our clients, our designs celebrate you, and each solution is unique, branding the client that we serve. As our name suggests, Nemesis is a collaborative design firm. Our clients challenge our thinking and we in turn challenge theirs. They understand that we are valuable business partners with them for the long haul; it is through this active communication that we arrive at the right solutions. This helps us in our passion for excellence and innovation.</p> <br>
          <img class="image-frame" src="images/small/small3.jpg" /> 
          <img class="image-frame" src="images/small/small4.jpg" />
           
          <p>The team at Nemesis Design Studio is diverse and broadly educated. We span three generations and two cultures. Our education in the world, and in university, ranges from fine art to cultural history, from interior architecture, graphic, and interactive design to web designing. This diversity brings depth to our design solutions.</p>
         
         
</div>
      
 <?php include('includes/rightside.php'); ?>
 <?php include('includes/footer.php'); ?>
        
	
		
        
   



