<?php
	include 'core/init.php';
    logged_in_redirect();
  ?>

<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Register</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
</head>

<body>

<div id="outer">

<div id="wrapper">
	
		
		<?php include('includes/header.php'); ?>
        
        <?php include('includes/nav.php'); ?>
        
        <?php include('includes/slider.php'); ?>
		<?php include('includes/rightside.php');
       
if (empty($_POST) === false) {
              $required_fields = array ('username','password','password_again','first_name','email','address_line_one','gender');
    foreach ($_POST as $key=>$value){
	if (empty($value) && in_array($key,$required_fields) === true){    $errors[] = '<em>Fields markes with an asterisk are required</em>';
	 break 1; }
	  
	 }
	 
	 if (empty($errors) === true) {
		 if (user_exists($_POST['username']) === true){
			 $errors[] = '<em>Sorry, the username \'' .$_POST['username'] . '\' is already taken.</em>';
		 }
		 
	 if (preg_match("/\\s/",$_POST['username']) == true) {
		 $errors[] = ' <em>Your username must not contain any spaces.</em>';
		 
	 }
		 
		if (strlen($_POST['password']) < 6) {
			$errors[] = '<em>Your password must be at least 6 characters.</em>'; }
		 
		 if ($_POST['password'] !== $_POST['password_again']){
			$errors[] = '<em>Your password do not match.</em>'; 
		 }
		 
if (filter_var($_POST['email'],FILTER_VALIDATE_EMAIL) === false){
			 $errors[] = '<em>A valid email address is required.</em>';
		 }
		 
		 if(email_exists($_POST['email']) === true){
		$errors[] = '<em>Sorry, the email \'' .$_POST['email'] . '\' is already in use.</em>';	 
		 }
		  
		 
	 }
		
		
			
}

?>
  

			
<div id="content">
<h1>Register</h1>

<p>
<?php

if (isset($_GET['success']) && empty ($_GET['success'])) {
	echo 'You\ ve been Registered successfully!';
} else {


		 if (empty($_POST) === false && empty($errors) === true){   
			 $register_data = array(
			 'username' 	=> $_POST['username'],
			 'password' 	=> $_POST['password'],
			 'first_name' 	=> $_POST['first_name'],
			 'last_name' 	=> $_POST['last_name'],
			 'email' 		=> $_POST['email'],
			 'address_line_one' 	=> $_POST['address_line_one'],
			 'gender'		=> $_POST['gender'],
			 );
			 register_user($register_data);
			 header('Location: registation.php?success');
			 exit();
			 
			 
		} else  {
			echo output_errors($errors);

		}

?> 
</p>
<p>In order to get Registered please fill up the form below as appropriate:</p>


<form action="" method="post">
 <ol>
 
 <li> 
 <label for="username">Username*</label>
 <input type="text" name="username">
 </li>
 
  <li> 
 <label for="password">Password*</label>
 <input type="password" name="password">
 </li>
 
 <li> 
 <label for="password_again">Password again*</label>
 <input type="password" name="password_again">
 </li>
 
 <li> 
 <label for="first_name">First name*</label>
 <input type="text" name="first_name">
 </li>
 
 
 <li> 
 <label for="last_name">Last name:</label>
 <input type="text" name="last_name">
 </li>
 
 <li> 
 <label for="email">Email*</label>
 <input type="text" name="email">
 </li>
 
  <li> 
 <label for="address_line_one">Address_line_one*</label>
 <input type="text" name="address_line_one">
 </li>
 
 <li> 
 <label for="gender">Gender*</label>                                                             
 <select name="gender" id="gender">
 <option value="male">Male</option>
 <option value="female">Female</option>
  </select>
 </li>
 
 

 <li>
 <input type="submit" class="submit" id="button" value="Register" >
 </li>
 </ol>

</form>
    </div>
        

<?php
include'includes/footer.php';
}
?>