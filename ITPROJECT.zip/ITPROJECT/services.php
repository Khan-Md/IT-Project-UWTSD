<?php
		include 'core/init.php';
?>

<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Services</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
</head>

<body>

<div id="outer">

<div id="wrapper">
	


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Services</h1>
<p>Here at Nemesis Design Studio we offer high quality, professional interior & web design services for our clients. By combining Interior design and Web designing in one place, we ensure our clients benefit from a single point of contact. This single point interior and web design service delivers high quality projects faster, and at a competitive cost.</p>
          <img class="image-frame" src="images/small/small5.jpg" /> 
          <img class="image-frame" src="images/small/small6.jpg" />  
<h3>Interior Design </h3>
          <p>Nemesis design studio believes in holistic interior design solutions the whole is greater than the sum of its parts. Our diverse set of skills allows us to provide this holistic design for our clients. We offer a complete range of services for the planning, design and delivery of interior environments. <br><br>This includes strategy, optional design plans, and budgets, along with 3D visualization and animation. Interiors must reflect your business and its brand. Careful material selection ensures an innovative interior environment that accurately reflects your requirements, image, values and budget.
 </p>
          <h3>Web Design </h3>
          <p>Here at Nemesis Design Studio, we are firm believers of clean online material, particularly when it comes to web design. Typically many websites are overworked with heavy content, ill-considered typography and layout. If you are looking for designers and developers to create a unique online experience for you and your brand then we are here to help.</p> <br>
          <img class="image-frame" src="images/small/small8.jpg" /> 
          <img class="image-frame" src="images/small/small10.jpg" />
           
          <p>Once you have provided a short brief,  we will continually liaise with you from providing initial concepts with structure, considered type, stunning imagery and user friendly navigation systems to the completed project. No matter what the size and scale of the job, we put 100% into everything that comes into our studio.</p>
          
</div>



 <?php include('includes/rightside.php'); ?>
 <?php include('includes/footer.php'); ?>
        
	
		
        
   



