         
<?php
include 'core/init.php';
protect_page();
admin_protect(); 
?>
<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Admin</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
  
</head>

<body>

<div id="outer">

<div id="wrapper">


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>

  	
<div id="content">
<h1>Admin</h1>
<p>Hi Admin welcome to <em>Nemesis Design Studio</em> what would you like to do today.</p> <br>   
<p class="sidebar-image-frame"><img class="image-frame" src="images/admin/admin3.jpg" /><a href="inventory_add.php"><img class="image-frame" src="images/admin/admin4.jpg" /></a><a href="inventory_list.php"><img class="image-frame" src="images/admin/admin5.jpg" /></a> <br>
In order to add new products into the system please click on to <a href="inventory_add.php">ADD</a> link from the Admin dropdown options. Once the new product added it will be visible in inventory list.<br/>
Besides to edit a particular Product details like: Changing Price, Description, Quantity, Images and others in addition to to delete a particular product from the database please click on <a href="inventory_list.php">EDIT OR DELET</a> link available on the top.


</p>         
         
</div>
       
 <?php include('includes/rightside.php'); ?>
 <?php include('includes/footer.php'); ?>
        
	
		
        
   




