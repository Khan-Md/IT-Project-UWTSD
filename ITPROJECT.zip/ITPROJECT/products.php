<?php
		include 'core/init.php';

?>
<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Products</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
</head>

<body>

<div id="outer">

<div id="wrapper">


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Products</h1>

<p>Here at Nemesis Design Studio, we sale high quality, interior designing materials consist of Lightings and Wallpapers. In addition to this we have authentic Paintings for sales tinted by innovative artists.Our diverse set of lighting, wallpaper and painting products allow us to provide holistic design for our clients.</p>
        <img class="image-frame" src="images/small/small18.jpg" /> 
        <img class="image-frame" src="images/small/small19.jpg" />  
        
          <h3>Lighting</h3>
          <p>Good lighting, in a home or business, is one of those things that are invisible - if it's done well. You only notice the lighting of a room if it's too bright or too dim, not if it's just right. Our goal is to offer quality Lightings is to our clients. You can always update a room and improve the atmosphere with good lighting; equally, nothing makes a room feel dated and unwelcoming like bad lighting.</p>    

          <h3>Wallpaper</h3>
          <p>Wallpaper is a kind of material used to cover and decorate the interior walls of homes, offices, and other buildings; it is one aspect of interior decoration. Wallpapers can appear plain as 'lining paper' (so that it can be painted), textured (such as Anaglyptic), with a regular repeating pattern design, or, much less commonly today, with a single non-repeating large design carried over a set of sheets.</p> <br>
          <img class="image-frame" src="images/small/small14.jpg" /> 
          <img class="image-frame" src="images/small/small15.jpg" />
          
          <h3>Painting</h3>
          <p>Painting is a mode of creative expression, and the forms are numerous. Drawing, composition or abstraction and other aesthetics may serve to manifest the expressive and conceptual intention of the practitioner.Paintings can be naturalistic and representational (as in a still life or landscape painting), photographic, abstract, be loaded with narrative content, symbolism, emotion or be political in nature.</p>
          
</div>


<?php include('includes/rightside.php'); ?>
<?php include('includes/footer.php'); ?>
        
	
		
        
   



