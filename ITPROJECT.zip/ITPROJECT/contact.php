<?php
		include 'core/init.php';
?>

<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Contact</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
   
</head>

<body>

<div id="outer">

<div id="wrapper">
	


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Contact Us Today!</h1>
          <p>If you have a Project or Company that requires creative input, please drop us a line or give us a call. We are passionate, enthusiastic and always ready for the next challenge. We will happily supply portfolios of past projects relevant to your own specifications so that you can see examples of our work.
 </p>
 <h3>Studio Address:<h3>
               <p>Studio A, Mercer Court 6 Candle Street, London, E1 4SF <br>
               Tel: 0208007007 <br>Email: Nemesis_bd89@yahoo.com
</p>
            <form id="contact" name="feedback" method="post" action="thankyou.php">
            <ol>
              <li><label for="name">Name</label>
              <input type="text" name="name" id="name"></li>
              
              <li><label for="telephone">Telephone</label>
              <input type="text" name="telephone" id="telephone"></li>
              
              <li><label for="email">Email</label>
              <input type="text" name="email" id="email"></li>
              
              <li><label for="comments">Comments</label>
              <textarea name="comments" id="comments" cols="45" rows="5"></textarea></li>
              
              <li>
              <input type="submit" class="submit" id="submit" value="Submit"></li>
             
             </ol> 
            </form>
            
</div>
 
<?php include('includes/rightside.php'); ?>
<?php include('includes/footer.php'); ?>
        
	
		
        
   



