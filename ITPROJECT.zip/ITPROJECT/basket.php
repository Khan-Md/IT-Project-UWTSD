<?php
		include 'core/init.php';
		require 'cart.php';
		protect_page();
?>

<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Basket</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />

</head>

<body>

<div id="outer">

<div id="wrapper">


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

<div id="content">
<h1>Basket</h1>
<p> 
<?php 
global $total;
	foreach($_SESSION as $name => $value){
		if ($value>0){
			if(substr($name,0,5) == 'cart_'){
				$id = substr($name,5,(strlen($name)-5));
				$get = mysql_query('SELECT id,name,price FROM products WHERE id='.mysql_real_escape_string((int)$id));
				while($get_row= mysql_fetch_assoc($get)) {
					$sub = $get_row['price']*$value;
					echo '<em> Product Name:</em>  '.$get_row['name'].'<em> x</em> '.$value.'@ &pound; '.number_format($get_row['price'],2). ' <em>=</em> &pound;'.number_format($sub,2).'<a href="cart.php?remove='. $id.'"> [<em>-</em>]</a> <a href="cart.php?add='.$id.'"> [<em>+</em>]</a> <a href="cart.php?delete='.$id.'"> [<em>Remove</em>]</a> <br/>';
					
				}
				
				$total += $sub;
				}
					
		}
		
			
	}
	if ($total==0){
	echo" <em><em>Your shopping basket is empty.</em></em>";
}else {
	echo '<p><em>Total:</em> &pound;'.number_format($total,2).'</p>';
	?>
 

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_cart">

<input type="hidden" name="upload" value="1">

<input type="hidden" name="business" value="Nemesis_Studio@yahoo.com">

<?php paypal_items();?>

<input type="hidden" name="currency_code" value="GBP">
<input type="hidden" name="amount" value="<?php $total; ?>">
<input name="submit" type="image" class="submit" src="http://www.paypal.com/en_US/i/btn/x-click-but03.gif" alt="Make payments with PayPal - it's fast, free and secure!">
</form>

<?php

}

?>
</p>   

         
</div>
    
 <?php include('includes/rightside.php'); ?>
 <?php include('includes/footer.php'); ?>
        
	
		
        
   



