<?php
include'core/init.php';
logged_in_redirect();
?>
 
<?php

 if (empty($_POST) === false){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if (empty($username) === true || empty ($password) === true){
		$errors[] = '<em>You need to enter a Username and Password.</em>';
		
	} else if (user_exists($username) === false) {
		$errors[] = ' <em>We can\'t find this Username. Have  you Registerd?</em>';
	}
	 
	  else if (user_active($username) === false){
		  $errors[] = ' <em>You haven\'t activated your account!</em>';
		  
	  }
	  
	  else{
		  
		  if (strlen($password) >32) {
			  $errors[] ='Password to long';
			  
			  }
		  $login = login($username, $password);
		  if ($login === false){
			  $errors[] = '<em>That username/password combination is incorect.</em>';
		  } else {
		    
			 $_SESSION[ 'user_id'] = $login;
			 header( 'Location: admin.php');
			 exit();
		  }
		    
		  
	  }
	
} else {
	$errors[]= 'No data received.';
}

 ?>

 
<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Login</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
    
</head>

<body>

<div id="outer">

<div id="wrapper">
	

<?php 

include('includes/header.php');         
include('includes/nav.php');                                                                             
include('includes/slider.php'); 
include('includes/rightside.php');

?>
        

<div id="content">
<h1>Nemesis Design Studio</h1>
<p>              
<?php if (empty($errors) === false) {
?>  <h3> We tried to log you in ,but....</h3> <br/>

<?php
	echo output_errors($errors);
}
?>
 </p> 
 </div>
 
<?php include('includes/footer.php'); ?>
 
 
 
 
 