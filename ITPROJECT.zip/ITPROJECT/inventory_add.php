       
<?php
include 'core/init.php';
protect_page();
admin_protect();
?>


<?php 

if (isset($_POST['name'])) {
	
    $name = mysql_real_escape_string($_POST['name']);
	$discription = mysql_real_escape_string($_POST['discription']);
	$price = mysql_real_escape_string($_POST['price']);
	$shipping = mysql_real_escape_string($_POST['shipping']);
	$quantity = mysql_real_escape_string($_POST['quantity']);
    $catagory_id = mysql_real_escape_string($_POST['catagory_id']);
	$sql = mysql_query("SELECT id FROM products WHERE name='$name' LIMIT 1");
	$productMatch = mysql_num_rows($sql); 
    if ($productMatch > 0) {
		echo 'Sorry you tried to place a duplicate "Product Name" into the system, <a href="inventory_list.php">click here</a>';
		exit();
	}
	
	$sql = mysql_query("INSERT INTO products (name, discription, price, shipping, quantity, catagory_id) 
        VALUES('$name','$discription','$price','$shipping','$quantity','$catagory_id')") or die (mysql_error());
     $id = mysql_insert_id();
	$newname = "$id.jpg";
	move_uploaded_file($_FILES['fileField']['tmp_name'], "images/products/$newname");
    header("location: inventory_list.php"); 
    exit();
}
?>



<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Add Products</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
    
</head>

<body>

<div id="outer">

<div id="wrapper">
	


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Add Products</h1>

   <h3>&darr; Add New Product Form &darr;</h3>
    
    <form action="inventory_add.php" enctype="multipart/form-data" name="myForm" id="myform" method="post">
    <ol>
          <li> <label for="name">Name</label>
               <input type="text" name="name" id="name">
          </li>
          
          
          <li><label for="discription">Description</label>
              <textarea name="discription" id="discription" cols="64" rows="5"></textarea></li>
          
          <li> <label for="price">Price(£)</label>
               <input type="text" name="price" id="price">
          </li>
          
          
          <li> <label for="shipping">Shipping(£)</label>
               <input type="text" name="shipping" id="shipping">
          </li>
          
          <li> <label for="quantity">Quantity</label>
               <input type="text" name="quantity" id="quantity">
          </li>
          
          <li> <label for="catagory_id">Category_id</label>
               <select name="catagory_id" id="catagory_id">
               <option value="1">Lighting(1)</option>
               <option value="2">Wallpaper(2)</option>
               <option value="3">Painting(3)</option>
               </select>
          </li>
          
           <li> <label for="name">Picture</label>
               <input type="file" name="fileField" id="fileField">
          </li>
          
          <li>   
               <input type="submit" class="submit"  id="button" value="Add This Item Now">
          </li>
          
          
       </ol>
    </form>
    
   <br />
  <br />


</div>

<?php include('includes/rightside.php'); ?>
<?php include('includes/footer.php'); ?>
        
	
		
        
   




