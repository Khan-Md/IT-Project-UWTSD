<?php
if (!isset($_SESSION))
session_start();
$page = 'basket.php';
include 'core/database/connect.php';

function loged_in() {
	return(isset($_SESSION['user_id'])) ? true : false;
	}
	
	if (loged_in() === false){
		header('Location: protected.php');
		
		exit();
	}

?>

<?php 

if (isset($_GET['add'])) {
	
	$quantity = mysql_query('SELECT id,quantity FROM products WHERE id='.mysql_real_escape_string((int)$_GET['add']));
	
	while($quantity_row = mysql_fetch_assoc($quantity)){
		
		if ($quantity_row['quantity'] !=$_SESSION['cart_'.(int)$_GET['add']]){
			$_SESSION['cart_'.(int)$_GET['add']]+='1';
	
		}
		
   }
	
	
	header('Location:'.$page);
	
}

if (isset($_GET['remove'])){
	$_SESSION['cart_'.(int)$_GET['remove']]--;
	header('Location:'.$page);
}

if (isset($_GET['delete'])){
	$_SESSION['cart_'.(int)$_GET['delete']]='0';
	header('Location:'.$page);
}



function paypal_items(){
	$num =0;
	foreach($_SESSION as $name => $value){
		if ($value!=0){
			
			if (substr($name, 0 ,5)== 'cart_'){
				$id =substr($name, 5, strlen($name)-5);
				$get = mysql_query('SELECT id,name,price,shipping FROM  products WHERE id='.mysql_real_escape_string((int)$id));
				while ($get_row = mysql_fetch_assoc($get)){
					$num++;
				echo '<input type="hidden" name="item_number_'.$num.' " value="'.$id.'">';
				echo '<input type="hidden" name="item_name_'.$num.' " value="'.$get_row['name'].'">';
				echo '<input type="hidden" name="amount_'.$num.' " value="'.$get_row['price'].'">';
			    echo '<input type="hidden" name="shipping_'.$num.' " value="'.$get_row['shipping'].'">';
				echo '<input type="hidden" name="shipping2_'.$num.' " value="'.$get_row['shipping'].'">';
				echo '<input type="hidden" name="quantity_'.$num.' " value="'.$value.'">';
				}
			}
		}
		
	}
}



?>