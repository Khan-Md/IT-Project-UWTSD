       
<?php
include 'core/init.php';
protect_page();
admin_protect();

?>


<?php 

if (isset($_POST['name'])) {
	
	$pid = mysql_real_escape_string($_POST['thisID']);
    $name = mysql_real_escape_string($_POST['name']);
	$discription = mysql_real_escape_string($_POST['discription']);
	$price = mysql_real_escape_string($_POST['price']);
	$shipping = mysql_real_escape_string($_POST['shipping']);
	$quantity = mysql_real_escape_string($_POST['quantity']);
    $catagory_id = mysql_real_escape_string($_POST['catagory_id']);
	$sql = mysql_query("UPDATE products SET name='$name', discription='$discription', price='$price', shipping='$shipping', quantity='$quantity', catagory_id='$catagory_id' WHERE id='$pid'");
	
	
	if ($_FILES['fileField']['tmp_name'] != "") {
	    $newname = "$pid.jpg";
	    move_uploaded_file($_FILES['fileField']['tmp_name'],"images/products/$newname");
	}
	header("location: inventory_list.php"); 
    exit();
}
?>


<?php 
if (isset($_GET['pid'])) {
	$targetID = $_GET['pid'];
    $sql = mysql_query("SELECT * FROM products WHERE id='$targetID' LIMIT 1");
    $productCount = mysql_num_rows($sql); 
    if ($productCount > 0) {
	    while($row = mysql_fetch_array($sql)){ 
             
			$name = $row["name"];
			$discription = $row["discription"];
			$price  = $row["price"];
			$shipping = $row["shipping"];
			$quantity = $row["quantity"];
			$catagory_id = $row["catagory_id"];
        }
    } else {
	    echo "Sorry that product dont exist.";
		exit();
    }
}
?>



<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Edit products</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
    
    
</head>

<body>

<div id="outer">

<div id="wrapper">
	


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Edit Products</h1>
   <h3>&darr; Edit Inventory Item Form &darr;</h3>
    
    <form action="inventory_edit.php" enctype="multipart/form-data" name="myForm" id="myform" method="post">
    <ol>
          <li> <label for="name">Name</label>
               <input type="text" name="name" id="name"  value="<?php echo $name; ?>">
          </li>
          
          
          <li><label for="discription">Description</label>
              <textarea name="discription" id="discription" cols="64" rows="5"><?php echo $discription;?>"</textarea>
          </li>
          
          <li> <label for="price">Price(£)</label>
               <input type="text" name="price" id="price" value="<?php echo $price; ?>">
          </li>
          
          
          <li> <label for="shipping">Shipping(£)</label>
               <input type="text" name="shipping" id="shipping" value="<?php echo $shipping; ?>">
          </li>
          
          <li> <label for="quantity">Quantity</label>
               <input type="text" name="quantity" id="quantity" value="<?php echo $quantity; ?>">
          </li>
          
          <li> <label for="catagory_id">Category_id</label>
               <select name="catagory_id" id="catagory_id" >
               <option value="<?php echo $catagory_id; ?>"><?php echo $catagory_id; ?></option>
               <option value="1">Lighting(1)</option>
               <option value="2">Wallpaper(2)</option>
               <option value="3">Painting(3)</option>
               </select>
          </li>
          
           <li> <label for="name">Picture</label>
               <input type="file" name="fileField" id="fileField">
          </li>
          
          <li>   
               <input name="thisID" type="hidden" value="<?php echo $targetID; ?>" />
               <input type="submit" class="submit"  id="button" value="Make Changes">
          </li>
          
            
    </ol>
    </form>
   
  <br />
  <br />


</div>


<?php include('includes/rightside.php'); ?>
<?php include('includes/footer.php'); ?>
        
	
		
        
   




