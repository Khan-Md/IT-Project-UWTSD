
<div id="rightside">


  <?php 
  if (logged_in() === true){
	  include'includes/widgets/loggedin.php';
	  
  } else {
	 include'includes/widgets/login.php'; 
  }
  
  include 'includes/widgets/user_count.php';
  ?>
 
            <h2>Latest Information</h2>
            <h4>March 30, 2013</h4>
            <h3>Bedroom Design Ideas</h3>
            <p>From traditional to contemporary to fun rooms for the kids, we've got all the practical advice you need to plan your new bedroom.</p>
            <img class="sidebar-image-frame" src="images/small/sidebar1.jpg" /> 
         
            <h4>March 30, 2013</h4>
            <h3>Kids' Bedrooms</h3>
            <p>We've got design ideas for kids' bedrooms, advice on themed rooms, the best ways to decorate and furnish.</p>
            <img class="sidebar-image-frame" src="images/small/sidebar2.jpg" /> 
            
            <h4>March 30, 2013</h4>
            <h3>Kitchen Planning Advice</h3>
            <p>Advice on kitchen layouts, lighting tips plus much more to make planning your kitchen a breeze.</p>
            <img class="sidebar-image-frame" src="images/small/sidebar3.jpg" />
        </div>
