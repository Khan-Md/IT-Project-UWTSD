<div id="logo">
			<h1>Nemesis Design Studio</h1>
            <h2> It's all about Rhythm,Continuity and Balance.</h2>
             
		</div>
      
        
          <div id="social-media-icons">
		<ul>
            	<li><a href="http://www.facebook.com"><img src="images/icons/facebook.png" /></a></li>
            	<li><a href="http://www.twitter.com"><img src="images/icons/twitter.png" /></a></li>
            	<li><a href="http://www.youtube.com"><img src="images/icons/youtube.png" /></a></li>
            
          </ul>
		</div>

        
        
      
		