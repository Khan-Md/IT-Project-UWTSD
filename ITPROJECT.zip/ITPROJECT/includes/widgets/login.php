               <div class="widget">
                <h2>Log in/Register</h2>
                <div class="inner">
                <form action="login.php" method="post">
                    
                   <ol id="login">
                   
                   <li>
                   <label for="username">Username:</label>
                   <input type="text" name="username">
                   </li>
                   <li> 
                    <label for="password">Password:</label>
                    <input type="password" name="password"> 
                    </li>
                    <li><input type="submit" class="submit" id="button" value="Log in"></li><br/>
                   
                    <li><a href="registation.php"><u>REGISTER</u></a></li>
                    
                  </ol>
                 </form>

              
               </div>
            </div> 