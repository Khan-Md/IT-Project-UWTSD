<div class="widget">
                <h2>Hello, <?php echo $user_data['first_name']; ?>!</h2>
                <div class="inner">
                <ul>
                <li><a href="logout.php"><u>LOG OUT</u></a></li>
                <li><a href="changepassword.php"><u>CHANGE PASSWORD</u></a></li>
                <li><a href="settings.php"><u> USER SETTINGS</u></a></li>
                
                
                </ul>

              
               </div>
            </div> 