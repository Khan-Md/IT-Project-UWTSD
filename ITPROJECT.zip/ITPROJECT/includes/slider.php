<div id="slider">

		<ul id="sliderContent">
				
			<li class="sliderImage">
				<img src="images/banner/banner6.jpg" />
				<span class=</span>
			</li>
			
            <li class="sliderImage">
				<img src="images/banner/banner8.jpg" />
				<span class=</span>
			</li>
            
            <li class="sliderImage">
				<img src="images/banner/banner10.jpg" />
				<span class=</span>
			</li>
             <li class="sliderImage">
				<img src="images/banner/banner11.jpg" />
				<span class=</span>
			</li>
            <li class="sliderImage">
				<img src="images/banner/banner12.jpg" />
				<span class=</span>
			</li>
            <li class="sliderImage">
				<img src="images/banner/banner13.jpg" />
				<span class=</span>
			</li>
            
			<div class="clear sliderImage"></div>
		</ul>
	
	</div>
 