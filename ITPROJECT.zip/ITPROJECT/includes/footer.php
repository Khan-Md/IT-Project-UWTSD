<div id="footer">
                <p class="footer-text">&copy;Copyright 2013 &bull; All Rights Reserved &bull; Nemesis Design Studio &bull; 07983784735</p>
                <p class="footer-text">Studio -A, Mercer court, London E1-4SF &bull; nemesis_bd89@yahoo.com</p>
             
		</div>
           
</body>
</html>