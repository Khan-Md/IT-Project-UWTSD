<div id="topnav"class="wrap">
          <ul id="nav">
            	<li><a href="index.php">HOME</a></li>
                <li><a href="products.php">PRODUCTS</a>
                <ul>
                <li><a href="lighting.php">LIGHTING</a></li>
                <li><a href="wallpaper.php">WALLPAPER</a></li>
                <li><a href="painting.php">PAINTING</a></li>
                </ul>
                
                </li>
                
                 <li><a href="services.php">SERVICES</a></li>
                 <li><a href="contact.php">CONTACT</a></li>
                 <li><a href="basket.php">BASKET</a></li>
                 
                 <li><?php global $session_user_id;
                 if (is_admin($session_user_id) === true){
	             echo '<a href="admin.php">ADMIN</a>';}?>
                 <ul>
                <li><a href="inventory_add.php">ADD</a></li>
                <li><a href="inventory_list.php">EDIT/DELETE</a></li>
                </ul>
                </li>

                
                
                
            
            </ul>
		</div>
		