       
<?php
include 'core/init.php';
protect_page();
admin_protect();
?>


<?php 
if (isset($_GET['deleteid'])) {
	echo 'Do you really want to delete product with ID of ' . $_GET['deleteid'] . '? <a href="inventory_list.php?yesdelete=' . $_GET['deleteid'] . '">Yes</a> | <a href="inventory_list.php">No</a>';
	exit();
}
if (isset($_GET['yesdelete'])) {
	$id_to_delete = $_GET['yesdelete'];
	$sql = mysql_query("DELETE FROM products WHERE id='$id_to_delete' LIMIT 1") or die (mysql_error());
	
	
    $pictodelete = ("../images/$id_to_delete.jpg");
    if (file_exists($pictodelete)) {
       		    unlink($pictodelete);
    }
	header("location: inventory_list.php"); 
    exit();
}
?>


<?php 
$product_list = "";
$sql = mysql_query("SELECT * FROM products ");
$productCount = mysql_num_rows($sql); 
if ($productCount > 0) {
	while($row = mysql_fetch_array($sql)){ 
             $id = $row["id"];
			 $name = $row["name"];
			 $price = $row["price"];
			 $product_list .= "<em>Product ID:</em> $id - <em>Name:</em> <strong>$name</strong> - £$price - &nbsp; &nbsp; &nbsp; <a href='inventory_edit.php?pid=$id'><em><u>Edit</u></em></a> &bull; <a href='inventory_list.php?deleteid=$id'><em><u>Delete</u></em></a><br />";
    }
} else {
	$product_list = "You have no product listed yet";
}
?>




<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
     <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Products List</title>
    <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
    <meta name=" interior designin services" content="Description Here" />
    
</head>

<body>

<div id="outer">

<div id="wrapper">
	


<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
  

		
<div id="content">
<h1>Products List</h1>
<P><?php echo $product_list; ?></P>
   
</div>

<?php include('includes/rightside.php'); ?>
<?php include('includes/footer.php'); ?>
        
	
		
        
   




