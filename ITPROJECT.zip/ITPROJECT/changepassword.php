<?php
		include 'core/init.php';
		protect_page();
		
		if (empty($_POST) === false){
		 $required_fields = array ('current_password','password','password_again');
		 
		 foreach ($_POST as $key=>$value){
	    if (empty($value) && in_array($key,$required_fields) === true){    $errors[] = '<em>Fields markes with an asterisk are required</em>';
	    break 1; }
	     
        }
	
        if (md5($_POST['current_password']) === $user_data['password']){
		
		if (trim($_POST['password']) !==  trim ($_POST['password_again'])){
			$errors[] = '<em>Your new password do not match.</em>';
		} else if (strlen($_POST['password']) < 6){
			$errors[] = '<em>Your password must be at least 6 characters.</em>';
		}
		
	    } else {
		$errors[] = '<em>Your current password is incorrect.</em>';
	    }
	
	
			 
}
		
		
?>
<!DOCTYPE HTML>

<html>
	<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/slider.js"></script>
    <script type="text/javascript" src="js/simple-menu.js"></script>
	
	<script type="text/javascript">  // This is the script for the banner slider
		$(document).ready(function() {
			$('#slider').s3Slider({
				timeOut: 6000
			});
		});
	</script>

	<link href='http://fonts.googleapis.com/css?family=News+Cycle:400,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
     
     
     <link href="css/styles.css" rel="stylesheet" type="text/css" media="screen">
    <link href="css/slider.css" rel="stylesheet" type="text/css" media="screen">
    <link href="css/simple-menu.css" rel="stylesheet" type="text/css" media="screen">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="cache" />
    <title>Change password</title>
   <meta name="keywords" content="interior design,web design,lighting,painting,wallpaper" />
   <meta name=" interior designin services" content="Description Here" />


</head>

<body>

<div id="outer">

<div id="wrapper">
	

<?php include('includes/header.php'); ?>
        
<?php include('includes/nav.php'); ?>
        
<?php include('includes/slider.php'); ?>
<?php include('includes/rightside.php'); ?>
  

			
<div id="content">
<h1>Change Password</h1>
          
 <p>
 <?php
  if (isset($_GET['success']) && empty ($_GET['success'])) {
	echo 'Your password has been changed.';
}else {
 
 
 if (empty($_POST) === false && empty($errors) === true){
	change_password($session_user_id, $_POST['password']);
	 header('Location: changepassword.php?success');
	 
 } else if (empty($errors) === false){
	echo output_errors($errors);
 }
 

 
 ?>
 </p>
<p> In order to change your password please fill out the form below:</p> 

<form action="" method="post">
 <ol>
 
 <li> 
 <label for="current_password">Current password*:</label>
 <input type="password" name="current_password">
 </li>
 
  <li> 
 <label for="password">New Password*:</label>
 <input type="password" name="password">
 </li>
 
 <li> 
 <label for="password_again"> New password again*:</label>
 <input type="password" name="password_again">
 </li>
 
 <li>
 <input type="submit" class="submit" id="button" value="Change password" >
</li>

 </ol>

</form>
   </div>
    

<?php 
 include('includes/footer.php');
}?>
        
	
		
        
   



